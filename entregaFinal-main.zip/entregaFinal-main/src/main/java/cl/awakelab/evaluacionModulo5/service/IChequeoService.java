package cl.awakelab.evaluacionModulo5.service;

import java.util.List;

import cl.awakelab.evaluacionModulo5.entity.Chequeo;



public interface IChequeoService {
	
	public List<Chequeo> readAll();

}
